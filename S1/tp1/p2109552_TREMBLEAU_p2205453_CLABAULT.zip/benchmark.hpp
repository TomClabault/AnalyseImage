class Benchmark
{
public:
	static void benchmark();
};